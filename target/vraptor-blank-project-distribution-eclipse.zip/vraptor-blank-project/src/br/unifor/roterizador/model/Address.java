package br.unifor.roterizador.model;


public class Address {	

	private String addressName;	
	private Point point;
	
	public String getAddressName() {
		return addressName;
	}

	public void setAddressName(String addressName) {
		this.addressName = addressName;
	}
		
	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	public Address(String addressName, Point point) {
		super();
		this.addressName = addressName;
		this.point = point;
	}

	public Address(String addressName) {
		super();
		this.addressName = addressName;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	


}
