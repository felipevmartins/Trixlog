package br.unifor.roterizador.model;


public class Route {
	
	private Address origin;
	private Address destination;
	private int duration;
	private int distance;
	
	public Address getOrigin() {
		return origin;
	}
	
	public void setOrigin(Address origin) {
		this.origin = origin;
	}
	
	public Address getDestination() {
		return destination;
	}
	
	public void setDestination(Address destination) {
		this.destination = destination;
	}
	
	public int getDuration() {
		return duration;
	}
	
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	public int getDistance() {
		return distance;
	}
	
	public void setDistance(int distance) {
		this.distance = distance;
	}
	
	public Route(Address origin, Address destination, int duration, int distance) {
		super();
		this.origin = origin;
		this.destination = destination;
		this.duration = duration;
		this.distance = distance;
	}
	
	public Route() {
		super();
		// TODO Auto-generated constructor stub
	}

}
