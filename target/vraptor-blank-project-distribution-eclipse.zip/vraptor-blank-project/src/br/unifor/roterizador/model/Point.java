package br.unifor.roterizador.model;

import java.util.List;


public class Point {
	
	private int id;
	private Coordinate coordinate;
	private List<Point> points;	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}
	
	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}

	public Point(Coordinate coordinate) {
		super();
		this.coordinate = coordinate;
	}

	
	

}
