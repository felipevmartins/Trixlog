package br.com.trixlog.dao;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class TagDao extends GenericDao {

}
